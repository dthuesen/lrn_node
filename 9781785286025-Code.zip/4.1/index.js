console.log('The first statement');

setTimeout(function() {
	console.log('The second statement');
}, 2000);

console.log('The third statement');
